package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.model.Product
import com.example.myapplication.ui.view.ManageProductActivity
import com.example.myapplication.ui.view.ProductAdapter
import com.example.myapplication.ui.view.ProfileActivity
import com.example.myapplication.ui.viewmodel.ProductViewModel

class MainActivity : AppCompatActivity() {
    // Deklarasi ViewModel dan Adapter
    private lateinit var productViewModel: ProductViewModel
    private lateinit var productAdapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inisialisasi ViewModel
        productViewModel = ViewModelProvider(this).get(ProductViewModel::class.java)

        // Inisialisasi RecyclerView dan set layout manager
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Inisialisasi adapter dengan daftar kosong dan set ke RecyclerView
        productAdapter = ProductAdapter(emptyList(), this::onEditClick, this::onDeleteClick)
        recyclerView.adapter = productAdapter

        // Observasi perubahan pada daftar produk dari ViewModel
        productViewModel.products.observe(this, Observer { products ->
            if (products != null) {
                // Update produk di adapter dan log hasil
                productAdapter.updateProducts(products)
                Log.d("MainActivity", "Products updated in adapter: $products")
            } else {
                Log.d("MainActivity", "No products available")
            }
        })

        // Observasi pesan error dari ViewModel
        productViewModel.error.observe(this, Observer { error ->
            Toast.makeText(this, error, Toast.LENGTH_LONG).show()
        })

        // Fetch semua produk saat aktivitas dibuat
        productViewModel.fetchAllProducts()

        // Inisialisasi tombol menu dan set listener untuk menampilkan popup menu
        val menuButton: ImageButton = findViewById(R.id.menu_button)
        menuButton.setOnClickListener { view ->
            showPopupMenu(view)
        }
    }

    // Fungsi untuk menampilkan popup menu
    private fun showPopupMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.menu_options, popupMenu.menu)

        // Set listener untuk item yang dipilih di popup menu
        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.optionProfile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.optionManageProducts -> {
                    val intent = Intent(this, ManageProductActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
        popupMenu.show()
    }

    // Fungsi untuk menangani klik edit produk
    private fun onEditClick(product: Product) {
        val intent = Intent(this, ManageProductActivity::class.java).apply {
            putExtra("productId", product.id)
            putExtra("productName", product.nama_produk)
            putExtra("productDescription", product.deskripsi)
            putExtra("productPrice", product.harga.toString())
            putExtra("productImage", product.gambar)
        }
        startActivity(intent)
    }

    // Fungsi untuk menangani klik hapus produk
    private fun onDeleteClick(product: Product) {
        productViewModel.deleteProduct(product.id).observe(this, Observer { response ->
            if (response.isSuccessful) {
                Toast.makeText(this, "Product deleted successfully", Toast.LENGTH_SHORT).show()
                productViewModel.fetchAllProducts()
            } else {
                Toast.makeText(this, "Failed to delete product", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
