package com.example.myapplication.data.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    // Base URL dari API
    private const val BASE_URL = "https://ikhsan-theta.vercel.app/"

    // Instance RetrofitClient yang akan digunakan untuk melakukan permintaan API
    val instance: ProductApi by lazy {
        // Inisialisasi Retrofit dengan konfigurasi yang diperlukan
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL) // Mengatur base URL untuk permintaan API
            .addConverterFactory(GsonConverterFactory.create()) // Menambahkan konverter untuk JSON menggunakan Gson
            .build()

        // Membuat implementasi dari interface ProductApi
        retrofit.create(ProductApi::class.java)
    }
}

