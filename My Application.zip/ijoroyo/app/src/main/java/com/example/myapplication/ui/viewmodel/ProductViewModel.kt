package com.example.myapplication.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.example.myapplication.data.model.Product
import com.example.myapplication.data.repository.ProductRepository
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

class ProductViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ProductRepository()
    private val _products = MutableLiveData<List<Product>>()
    val products: LiveData<List<Product>> get() = _products
    private val _error = MutableLiveData<String>()
    val error: LiveData<String> get() = _error

    fun fetchAllProducts() {
        viewModelScope.launch {
            try {
                val response = repository.getAllProducts()
                if (response.isSuccessful) {
                    response.body()?.let { productResponse ->
                        _products.postValue(productResponse.products)
                        Log.d("ProductViewModel", "Products fetched: ${productResponse.products}")
                    }
                } else {
                    _error.postValue("Error: ${response.code()}")
                }
            } catch (e: HttpException) {
                _error.postValue("HttpException: ${e.message}")
            } catch (e: IOException) {
                _error.postValue("IOException: ${e.message}")
            }
        }
    }

    fun getProductById(id: String) = liveData {
        emit(repository.getProductById(id).body()?.products?.firstOrNull())
    }

    fun createProduct(product: Product) = liveData {
        emit(repository.createProduct(product))
    }

    fun updateProduct(id: String, product: Product) = liveData {
        emit(repository.updateProduct(id, product))
    }

    fun deleteProduct(id: String) = liveData {
        emit(repository.deleteProduct(id))
    }
}
