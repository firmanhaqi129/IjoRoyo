package com.example.myapplication.data.repository

import com.example.myapplication.data.api.RetrofitClient
import com.example.myapplication.data.model.Product
import com.example.myapplication.data.model.ProductResponse
import retrofit2.Response

class ProductRepository {
    private val api = RetrofitClient.instance

    suspend fun getAllProducts(): Response<ProductResponse> {
        return api.getAllProducts()
    }

    suspend fun getProductById(id: String): Response<ProductResponse> {
        return api.getProductById(id)
    }

    suspend fun createProduct(product: Product): Response<ProductResponse> {
        return api.createProduct(product)
    }

    suspend fun updateProduct(id: String, product: Product): Response<ProductResponse> {
        return api.updateProduct(id, product)
    }

    suspend fun deleteProduct(id: String): Response<ProductResponse> {
        return api.deleteProduct(id)
    }
}
