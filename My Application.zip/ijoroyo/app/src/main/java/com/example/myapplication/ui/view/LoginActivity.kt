package com.example.myapplication.ui.view


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R
import com.example.myapplication.data.repository.UserRepository
import com.example.myapplication.data.room.AppDatabase
import com.example.myapplication.ui.viewmodel.UserViewModel
import com.example.myapplication.ui.viewmodel.UserViewModelFactory
import com.example.myapplication.utils.PreferenceHelper
import com.example.myapplication.utils.Status

class LoginActivity : AppCompatActivity() {
    private val userViewModel: UserViewModel by viewModels {
        UserViewModelFactory(UserRepository(AppDatabase.getDatabase(application).userDao()))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername: EditText = findViewById(R.id.etUsername)
        val etPassword: EditText = findViewById(R.id.etPassword)
        val btnLogin: Button = findViewById(R.id.btnLogin)
        val btnRegister: Button = findViewById(R.id.btnRegister)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Semua kolom harus diisi", Toast.LENGTH_SHORT).show()
            } else {
                userViewModel.login(username, password).observe(this, { resource ->
                    when (resource.status) {
                        Status.SUCCESS -> {
                            Toast.makeText(this, "Login berhasil", Toast.LENGTH_SHORT).show()
                            PreferenceHelper.setLoggedIn(this, true)
                            PreferenceHelper.setUsername(this, username)
                            startActivity(Intent(this, MainActivity::class.java))
                            finish()
                        }
                        Status.ERROR -> {
                            Toast.makeText(this, "Username atau password salah", Toast.LENGTH_SHORT).show()
                        }
                        Status.LOADING -> {
                            // Handle loading state if needed
                        }
                    }
                })
            }
        }

        btnRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}
