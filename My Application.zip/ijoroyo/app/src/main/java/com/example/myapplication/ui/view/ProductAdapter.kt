package com.example.myapplication.ui.view

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myapplication.R
import com.example.myapplication.data.model.Product

// Adapter untuk menampilkan daftar produk dalam RecyclerView
class ProductAdapter(
    private var products: List<Product>,
    private val onEditClick: (Product) -> Unit,
    private val onDeleteClick: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    // ViewHolder untuk menampilkan item produk
    class ProductViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val productName: TextView = view.findViewById(R.id.productName)
        private val productImage: ImageView = view.findViewById(R.id.productImage)
        private val btnMenu: ImageButton = view.findViewById(R.id.btnMenu)

        // Bind data produk ke dalam view
        fun bind(product: Product, onEditClick: (Product) -> Unit, onDeleteClick: (Product) -> Unit) {
            productName.text = product.nama_produk
            // Menggunakan Glide untuk memuat gambar produk
            Glide.with(itemView.context).load(product.gambar).into(productImage)

            // Klik pada item untuk membuka DetailActivity
            itemView.setOnClickListener {
                val context = itemView.context
                val intent = Intent(context, DetailActivity::class.java).apply {
                    putExtra("productName", product.nama_produk)
                    putExtra("productDescription", product.deskripsi)
                    putExtra("productPrice", product.harga.toString())
                    putExtra("productImage", product.gambar)
                }
                context.startActivity(intent)
            }

            // Klik pada tombol menu untuk menampilkan popup menu
            btnMenu.setOnClickListener { view ->
                showPopupMenu(view, product, onEditClick, onDeleteClick)
            }
        }

        // Menampilkan popup menu dengan opsi edit dan delete
        private fun showPopupMenu(view: View, product: Product, onEditClick: (Product) -> Unit, onDeleteClick: (Product) -> Unit) {
            val popupMenu = PopupMenu(view.context, view)
            popupMenu.menuInflater.inflate(R.menu.product_item_menu, popupMenu.menu)
            popupMenu.setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.optionEdit -> {
                        onEditClick(product)
                        true
                    }
                    R.id.optionDelete -> {
                        onDeleteClick(product)
                        true
                    }
                    else -> false
                }
            }
            popupMenu.show()
        }
    }

    // Membuat ViewHolder baru untuk item produk
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    // Mengikat data produk ke dalam ViewHolder
    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(products[position], onEditClick, onDeleteClick)
    }

    // Mendapatkan jumlah total item dalam daftar produk
    override fun getItemCount(): Int = products.size

    // Memperbarui daftar produk dan memberitahu adapter untuk memperbarui tampilan
    fun updateProducts(newProducts: List<Product>) {
        products = newProducts
        notifyDataSetChanged()
    }
}
