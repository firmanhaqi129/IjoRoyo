package com.example.myapplication.ui.view

import android.content.Intent
import android.os.Bundle
import android.view.View // Pastikan untuk mengimpor View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.MainActivity
import com.example.myapplication.R
import com.example.myapplication.data.model.Product
import com.example.myapplication.ui.viewmodel.ProductViewModel

class ManageProductActivity : AppCompatActivity() {
    private lateinit var productViewModel: ProductViewModel
    private var productId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_product)

        productViewModel = ViewModelProvider(this).get(ProductViewModel::class.java)

        val productName: EditText = findViewById(R.id.editProductName)
        val productDescription: EditText = findViewById(R.id.editProductDescription)
        val productPrice: EditText = findViewById(R.id.editProductPrice)
        val productImage: EditText = findViewById(R.id.editProductImage)
        val btnAddProduct: Button = findViewById(R.id.btnAddProduct)
        val btnUpdateProduct: Button = findViewById(R.id.btnUpdateProduct)
        val btnDeleteProduct: Button = findViewById(R.id.btnDeleteProduct)

        // Check if we are updating an existing product
        productId = intent.getStringExtra("productId")
        if (productId != null) {
            productName.setText(intent.getStringExtra("productName"))
            productDescription.setText(intent.getStringExtra("productDescription"))
            productPrice.setText(intent.getStringExtra("productPrice"))
            productImage.setText(intent.getStringExtra("productImage"))

            btnAddProduct.visibility = View.GONE
            btnUpdateProduct.visibility = View.VISIBLE
            btnDeleteProduct.visibility = View.VISIBLE
        } else {
            btnAddProduct.visibility = View.VISIBLE
            btnUpdateProduct.visibility = View.GONE
            btnDeleteProduct.visibility = View.GONE
        }

        btnAddProduct.setOnClickListener {
            val product = Product(
                id = "", // ID akan dibuat oleh server
                nama_produk = productName.text.toString(),
                deskripsi = productDescription.text.toString(),
                harga = productPrice.text.toString().toInt(),
                gambar = productImage.text.toString()
            )
            productViewModel.createProduct(product).observe(this, {
                // Handle response
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            })
        }

        btnUpdateProduct.setOnClickListener {
            val product = Product(
                id = productId ?: "", // Set ID produk yang akan diupdate
                nama_produk = productName.text.toString(),
                deskripsi = productDescription.text.toString(),
                harga = productPrice.text.toString().toInt(),
                gambar = productImage.text.toString()
            )
            productViewModel.updateProduct(product.id, product).observe(this, {
                // Handle response
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            })
        }

        btnDeleteProduct.setOnClickListener {
            productId?.let {
                productViewModel.deleteProduct(it).observe(this, {
                    // Handle response
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                })
            }
        }
    }
}
