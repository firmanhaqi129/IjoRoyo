package com.example.myapplication.ui.view

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.myapplication.R

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val productName = intent.getStringExtra("productName")
        val productDescription = intent.getStringExtra("productDescription")
        val productPrice = intent.getStringExtra("productPrice")
        val productImage = intent.getStringExtra("productImage")

        val detailProductName: TextView = findViewById(R.id.detail_productName)
        val detailProductDescription: TextView = findViewById(R.id.detail_productDescription)
        val detailProductPrice: TextView = findViewById(R.id.detail_productPrice)
        val detailProductImage: ImageView = findViewById(R.id.detail_productImage)
        val btnAddToCart: Button = findViewById(R.id.btnAddToCart)
        val btnBuyNow: Button = findViewById(R.id.btnBuyNow)

        detailProductName.text = productName
        detailProductDescription.text = productDescription
        detailProductPrice.text = productPrice
        Glide.with(this).load(productImage).into(detailProductImage)

        btnAddToCart.setOnClickListener {
            val intent = Intent(this, AddToCartActivity::class.java)
            startActivity(intent)
        }

        btnBuyNow.setOnClickListener {
            val intent = Intent(this, BuyNowActivity::class.java)
            startActivity(intent)
        }
    }
}
