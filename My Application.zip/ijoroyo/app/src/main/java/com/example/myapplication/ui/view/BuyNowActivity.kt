package com.example.myapplication.ui.view

import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.R

class BuyNowActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buy_now)

        val buyNowImage: ImageView = findViewById(R.id.buy_now_image)
        val animation = AnimationUtils.loadAnimation(this, R.anim.bounce)
        buyNowImage.startAnimation(animation)

        val btnProceedPayment: Button = findViewById(R.id.btn_proceed_payment)
        val btnCancel: Button = findViewById(R.id.btn_cancel)

        btnProceedPayment.setOnClickListener {
            // Implement payment functionality here
        }

        btnCancel.setOnClickListener {
            finish()
        }
    }
}
