package com.example.myapplication.data.api

import com.example.myapplication.data.model.Product
import com.example.myapplication.data.model.ProductResponse
import retrofit2.Response
import retrofit2.http.*

interface ProductApi {

    // Mengambil semua produk dari server menggunakan metode GET
    @GET("products")
    suspend fun getAllProducts(): Response<ProductResponse>

    // Mengambil detail produk berdasarkan ID menggunakan metode GET
    @GET("products/{id}")
    suspend fun getProductById(@Path("id") id: String): Response<ProductResponse>

    // Membuat produk baru menggunakan metode POST
    @POST("products")
    suspend fun createProduct(@Body product: Product): Response<ProductResponse>

    // Memperbarui produk yang ada berdasarkan ID menggunakan metode PUT
    @PUT("products/{id}")
    suspend fun updateProduct(@Path("id") id: String, @Body product: Product): Response<ProductResponse>

    // Menghapus produk berdasarkan ID menggunakan metode DELETE
    @DELETE("products/{id}")
    suspend fun deleteProduct(@Path("id") id: String): Response<ProductResponse>
}

