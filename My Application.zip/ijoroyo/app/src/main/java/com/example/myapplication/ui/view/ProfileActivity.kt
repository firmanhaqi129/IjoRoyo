package com.example.myapplication.ui.view

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.Observer
import com.bumptech.glide.Glide
import com.example.myapplication.MainActivity
import com.example.myapplication.R
import com.example.myapplication.data.repository.UserRepository
import com.example.myapplication.data.room.AppDatabase
import com.example.myapplication.ui.viewmodel.UserViewModel
import com.example.myapplication.ui.viewmodel.UserViewModelFactory
import com.example.myapplication.utils.PreferenceHelper
import com.example.myapplication.utils.Status
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ProfileActivity : AppCompatActivity() {

    private lateinit var tvUsername: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvBio: TextView
    private lateinit var tvPhoneNumber: TextView
    private lateinit var tvAddress: TextView
    private lateinit var ivProfilePhoto: ImageView
    private lateinit var toolbar: Toolbar

    private val userViewModel: UserViewModel by viewModels {
        UserViewModelFactory(UserRepository(AppDatabase.getDatabase(application).userDao()))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        tvUsername = findViewById(R.id.tvUsername)
        tvEmail = findViewById(R.id.tvEmail)
        tvBio = findViewById(R.id.tvBio)
        tvPhoneNumber = findViewById(R.id.tvPhoneNumber)
        tvAddress = findViewById(R.id.tvAddress)
        ivProfilePhoto = findViewById(R.id.ivProfilePhoto)
        val btnEditProfile: Button = findViewById(R.id.btnEditProfile)
        val btnLogout: Button = findViewById(R.id.btnLogout)

        loadProfileData()

        btnEditProfile.setOnClickListener {
            val intent = Intent(this, EditProfileActivity::class.java)
            startActivityForResult(intent, REQUEST_EDIT_PROFILE)
        }

        btnLogout.setOnClickListener {
            PreferenceHelper.clearUserDetails(this)
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_EDIT_PROFILE && resultCode == RESULT_OK) {
            loadProfileData()
            Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadProfileData() {
        val username = PreferenceHelper.getUsername(this)
        username?.let {
            userViewModel.getUserByUsername(it).observe(this, Observer { user ->
                user?.let {
                    tvUsername.text = "Username: ${user.username}"
                    tvEmail.text = "Email: ${user.email}"
                    tvBio.text = "Bio: ${user.bio}"
                    tvPhoneNumber.text = "Phone Number: ${user.phoneNumber}"
                    tvAddress.text = "Address: ${user.address}"
                    user.profilePhotoUrl?.let { photoUrl ->
                        Glide.with(this)
                            .load(photoUrl)
                            .placeholder(R.drawable.ic_upload)
                            .circleCrop()
                            .into(ivProfilePhoto)
                    }
                }
            })
        }
    }

    companion object {
        const val REQUEST_EDIT_PROFILE = 1
    }
}
