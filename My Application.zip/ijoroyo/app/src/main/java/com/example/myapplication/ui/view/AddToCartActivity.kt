package com.example.myapplication.ui.view

import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class AddToCartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_to_cart)

        val cartImage: ImageView = findViewById(R.id.cart_image)
        val animation = AnimationUtils.loadAnimation(this, R.anim.bounce)
        cartImage.startAnimation(animation)

        val btnContinueShopping: Button = findViewById(R.id.btn_continue_shopping)
        val btnViewCart: Button = findViewById(R.id.btn_view_cart)

        btnContinueShopping.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        btnViewCart.setOnClickListener {
            // Implement view cart functionality here
        }
    }
}
