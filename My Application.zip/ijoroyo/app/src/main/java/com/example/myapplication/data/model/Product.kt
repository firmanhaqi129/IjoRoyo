package com.example.myapplication.data.model

// Data class untuk merepresentasikan sebuah produk
data class Product(
    val id: String,
    val nama_produk: String,
    val deskripsi: String,
    val harga: Int,
    val gambar: String
)

// Data class untuk merepresentasikan respon dari API yang berisi informasi produk
data class ProductResponse(
    val error: Boolean,
    val message: String,
    val count: Int,
    val products: List<Product>
)

